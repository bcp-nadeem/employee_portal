<div class="content-wrapper">
   <div class="container-xxl flex-grow-1 container-p-y">
    <h4 class="fw-bold "><a href="<?php echo base_url($this->session->userdata('user_role')==1 ? 'employee/dashboard' : 'supervisor/dashboard'); ?>"><i class='bx bx-left-arrow-alt'></i> BACK</a></h4>
       <h4 class="fw-bold py-1 mb-3"><span class="text-muted fw-light"> Dashboard / </span> Evaluation List</h4>
         <div class="card">
            <div class="table-responsive text-nowrap">
                <table id="<?php echo $table_name; ?>" class="table">
                    <thead class="table-light">
                        
                    </thead>
                    <tbody class="table-border-bottom-0">

                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
