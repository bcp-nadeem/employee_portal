
<script>
// Initialize jscolor picker
document.querySelectorAll('.jscolor').forEach(input => {
    new jscolor(input, {
        format: 'hex'
    });
});

// Handle color box clicks
document.querySelectorAll('.color-box').forEach(box => {
    box.addEventListener('click', function() {
        const color = this.dataset.color;
        const modalId = this.closest('.modal').id;
        const input = document.querySelector(`#${modalId} .jscolor`);
        input.value = color.replace('#', '');
        input.style.backgroundColor = color;
    });
});

// Handle level changes
$('.employee_level').on('change', function() {
    const levelId = $(this).val();
    const modal = $(this).closest('.modal');

    $.ajax({
        url: '<?php echo base_url("admin/AM_Controller/getSubLevels"); ?>',
        type: 'POST',
        data: { level_id: levelId },
        success: function(response) {
            const subLevels = JSON.parse(response);

            let options = '<option value="">Select Sub Level</option>';
            
            subLevels.forEach(level => {
                options += `<option value="${level.employee_sub_level_id}">${level.employee_sub_level_name}</option>`;
            });
            
            modal.find('.emp_sub_level').html(options);
        }
    });
});
</script>
    <!-- Employee Email Check is avalible -->
    <script>

        $(document).ready(function() {
            $("#vaild_email").hide();
            $("#login_email").keyup(function(){
                var email = $("#login_email").val();
                // console.log(email);
                if(email != ''){
                  $.ajax({
                  url:"<?php echo base_url(); ?>admin/AM_Controller/checkValidAccount",
                  method:"POST",
                  data:{email:email},
                  success:function(data){
                    if(data==1){
                      $("#vaild_email").show();
                    }else{
                      $("#vaild_email").hide();
                    }
                  }
                  });
                }
            });
        });

        $(document).ready(function(){
            $('#department_id').change(function(){
                var department_id = $('#department_id').val();
                if(department_id != ''){
                $.ajax({
                url:"<?php echo base_url(); ?>admin/AM_Controller/fetchDepartmentDrop",
                method:"POST",
                data:{department_id:department_id},
                success:function(data)
                {
                $('#designation_id').html(data);
                }
                });
                }
            });
        });

        // ... existing code ...

        $(document).ready(function() {
            $('.employee_level').on('change', function() {
                var levelId = $(this).val();
                $.ajax({
                    url:"<?php echo base_url(); ?>admin/AM_Controller/getSubLevels",
                    type: 'POST',
                    data: {level_id: levelId},
                    success: function(response) {
                        var data = JSON.parse(response);
                        
                        var html = '';
                        
                        if(data && data.length > 0) {
                            html = '<option value="">Select sub level</option>';
                            $.each(data, function(index, item) {
                                html += '<option value="' + item.employee_sub_level_id + '">' + item.employee_sub_level_name + '</option>';
                            });
                            $('.emp_sub_level').prop('disabled', false); // Enable the select
                        } else {
                            html = '<option value="">No sub levels available</option>';
                        }
                        
                        $('.emp_sub_level').html(html).trigger('change'); // Trigger change event for select2
                        $('.sub-level-show').show();
                    },
                    error: function(xhr, status, error) {
                        console.log('Error:', error);
                    }
                });
            });

            // Initialize select2
            $('.emp_sub_level').select2({
                width: '100%'
            });
        });

        

        // $(document).ready(function() {
        //     $('.employee_level').on('change', function() {
        //         var levelId = $(this).val();
        //         console.log('Selected Level:', levelId);
                
        //         if (!levelId) {
        //             console.log('No level selected');
        //             return;
        //         }
                
        //         $.ajax({
        //             url:"<?php //echo base_url(); ?>admin/AM_Controller/getUserRole",
        //             type: 'POST',
        //             data: {employee_level: levelId},
        //             dataType: 'json',
        //             success: function(response) {
        //                 console.log('Raw response:', response);
                        
        //                 if (response && response.status === 'success' && response.employee_level_value) {
        //                     var html = '<input type="hidden" name="user_role" value="' + response.employee_level_value + '">';
        //                     $('.user_role').html(html);
        //                     console.log('User role set to:', response.employee_level_value);
        //                 } else {
        //                     console.log('Invalid response format:', response);
        //                     $('.user_role').empty();
        //                 }
        //             },
        //             error: function(xhr, status, error) {
        //                 console.error('AJAX Error:', error);
        //                 console.log('Status:', status);
        //                 console.log('Response:', xhr.responseText);
        //                 $('.user_role').empty();
        //             }
        //         });
        //     });
        // });

        $(document).ready(function() {
            // Existing level change handler
            $('.employee_level, .emp_sub_level').on('change', function() {
                var levelId = $('.employee_level').val();
                var subLevelId = $('.emp_sub_level').val();
                
                $.ajax({
                    url: "<?php echo base_url(); ?>admin/AM_Controller/getSpectrumByLevel",
                    type: 'POST',
                    data: {
                        level_id: levelId,
                        sub_level_id: subLevelId
                    },
                    success: function(response) {
                        var data = JSON.parse(response);
                        var html = '<option value="" selected disabled>Select Spectrum</option>';
                        
                        if(data && data.length > 0) {
                            $.each(data, function(index, item) {
                                html += '<option value="' + item.spectrum_id + '" data-color="' + item.spectrum_color_code + '">' 
                                    + item.spectrum_color_name + '</option>';
                            });
                        }
                        
                        $('#spectrum_select').html(html);
                        $('#spectrum_color_preview').css('background-color', ''); // Reset color preview
                    }
                });
            });

            // Add spectrum color preview handler
            $('#spectrum_select').on('change', function() {
                var selectedOption = $(this).find('option:selected');
                var colorCode = selectedOption.data('color');
                if(colorCode) {
                    $('.holder img').css('border-color', '#'+colorCode);
                } else {
                    $('.holder img').css('border-color', '#eee'); // Reset to default border color
                }

            });
        });

        // Add Department Handler
          $('#saveDepartment').on('click', function() {
              var departmentName = $('#new_department_name').val();
              if(departmentName) {
                  $.ajax({
                      url: "<?php echo base_url(); ?>admin/AM_Controller/addDepartmentDynamic",
                      type: 'POST',
                      data: { department_name: departmentName },
                      success: function(response) {
                          var data = JSON.parse(response);
                          if(data.status === 'success') {
                              // Add new option to select
                              $('#department_id').append(new Option(departmentName, data.department_id));
                              // Close modal
                              $('#addDepartmentModal').modal('hide');
                              // Clear input
                              $('#new_department_name').val('');
                              // Show success message
                              alert('Department added successfully!');
                          } else {
                              alert('Failed to add department');
                          }
                      },
                      error: function() {
                          alert('Error occurred while adding department');
                      }
                  });
              } else {
                  alert('Please enter department name');
              }
          });

          // Add Designation Handler
          // Add Designation Handler
            $('#saveDesignation').on('click', function() {
                var designationName = $('#new_designation_name').val();
                var departmentId = $('#designation_department_id').val();  // Changed from d_department_id
                

                console.log(designationName, departmentId);

                if(!designationName || !departmentId) {
                    alert('Please enter designation name and select department');
                    return;
                }
                
                $.ajax({
                    url: "<?php echo base_url(); ?>admin/AM_Controller/addDesignationDynamic",
                    type: 'POST',
                    data: { 
                        designation_name: designationName,
                        department_id: departmentId
                    },
                    success: function(response) {

                    console.log(response);

                        var data = JSON.parse(response);
                        if(data.status === 'success') {
                            if($('#department_id').val() === departmentId) {
                                $('#designation_id').append(new Option(designationName, data.designation_id));
                            }
                            $('#addDesignationModal').modal('hide');
                            $('#new_designation_name').val('');
                            $('#designation_department_id').val('');
                            alert('Designation added successfully!');
                        } else {
                            alert(data.message || 'Failed to add designation');
                        }
                    },
                    error: function() {
                        alert('Error occurred while adding designation');
                    }
                });
            });

$(document).ready(function() {
    $('#spectrum_value').on('change', function() {
      var spectrumId = $(this).val();
      
      // Debug log
      console.log('Selected spectrum ID:', spectrumId);
      
      // Clear current options
      $('#section_dropdown').empty().append('<option selected disabled>Please select section name</option>');
      
      if(spectrumId) {
          $.ajax({
              url: '<?php echo base_url("admin/AM_Controller/getSectionsBySpectrum/"); ?>' + spectrumId,
              type: 'POST',
              dataType: 'json',
              success: function(response) {
                  console.log('AJAX Response:', response); // Debug log
                  
                  if(response && response.sections && response.sections.length > 0) {
                      $.each(response.sections, function(key, value) {
                          $('#section_dropdown').append(
                              $('<option></option>')
                                  .attr('value', value.section_id)
                                  .text(value.section_name)
                          );
                      });
                      // Trigger Select2 to update
                      $('#section_dropdown').trigger('change');
                  } else {
                      console.log('No sections found for this spectrum');
                      $('#section_dropdown').append(
                          $('<option></option>')
                              .attr('disabled', true)
                              .text('No sections available')
                      );
                  }
              },
              error: function(xhr, status, error) {
                  console.error('AJAX Error:', error);
                  console.log('Status:', status);
                  console.log('Response:', xhr.responseText);
              }
          });
      }
  });
  });

        </script>

</body>
</html>